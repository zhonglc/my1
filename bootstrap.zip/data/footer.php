<?php
header('Content-Type:text/html;charset=UTF-8');
?>
      <div class="footer">
      <div class="map" id="baidu-map"></div>
      <div class="circle">
        <div class="address">
          <h5>Address</h5>
          <p>fkjdsfkljsdflksjafl</p>
          <a href="#">点击这里关闭橙色圆框</a>
        </div>
      </div>
      </div>
    <div class="copyright">
      <p>版权所有</p>
     </div>