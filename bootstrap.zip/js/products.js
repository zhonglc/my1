$('#header').load('data/header.php');
$('#footer').load('data/footer.php');